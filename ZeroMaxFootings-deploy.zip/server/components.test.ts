import { describe, it, expect } from "vitest";

describe("ServiceGuideCharacter Component", () => {
  it("should have specialist character data defined", () => {
    const characterData = {
      specialist: {
        name: "Shoe Specialist",
        image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-shoe-specialist-gMbDBPCA7MhHn5RheS99Yc.webp",
        alt: "Professional shoe repair specialist",
      },
    };
    
    expect(characterData.specialist.name).toBe("Shoe Specialist");
    expect(characterData.specialist.image).toContain("cloudfront");
    expect(characterData.specialist.alt).toBe("Professional shoe repair specialist");
  });

  it("should have cleaning character data defined", () => {
    const characterData = {
      cleaning: {
        name: "Cleaning Expert",
        image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-cleaning-expert-ETA9KNPf4t6cmEzKTJQMco.webp",
        alt: "Professional footwear cleaning expert",
      },
    };
    
    expect(characterData.cleaning.name).toBe("Cleaning Expert");
    expect(characterData.cleaning.image).toContain("cloudfront");
  });

  it("should have restoration character data defined", () => {
    const characterData = {
      restoration: {
        name: "Restoration Master",
        image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-restoration-master-WbpWqjQZbLcHTew4XaKAvR.webp",
        alt: "Expert restoration specialist",
      },
    };
    
    expect(characterData.restoration.name).toBe("Restoration Master");
    expect(characterData.restoration.image).toContain("cloudfront");
  });

  it("should support different animation types", () => {
    const animationTypes = ["float", "bounce", "slide"] as const;
    
    animationTypes.forEach((type) => {
      const animationClass = {
        float: "animate-float",
        bounce: "animate-bounce",
        slide: "animate-slide-in",
      }[type];
      
      expect(animationClass).toBeDefined();
      expect(animationClass).toContain("animate-");
    });
  });

  it("should support left and right positioning", () => {
    const positions = ["left", "right"] as const;
    
    positions.forEach((position) => {
      const orderClass = position === "left" ? "md:order-first" : "md:order-last";
      expect(orderClass).toBeDefined();
      expect(orderClass).toContain("md:");
    });
  });
});

describe("ServiceGuideCharacterRow Component", () => {
  it("should render with title and description", () => {
    const props = {
      title: "Expert Shoe Repair",
      description: "Our shoe repair specialist brings years of experience",
      character: "specialist" as const,
      position: "right" as const,
    };
    
    expect(props.title).toBe("Expert Shoe Repair");
    expect(props.description).toContain("specialist");
    expect(props.character).toBe("specialist");
  });

  it("should support all three character types in rows", () => {
    const characters = ["specialist", "cleaning", "restoration"] as const;
    
    characters.forEach((character) => {
      expect(character).toBeDefined();
      expect(["specialist", "cleaning", "restoration"]).toContain(character);
    });
  });

  it("should support alternating left and right positions", () => {
    const rows = [
      { position: "right", character: "specialist" },
      { position: "left", character: "cleaning" },
      { position: "right", character: "restoration" },
    ];
    
    rows.forEach((row, index) => {
      expect(row.position).toBe(index % 2 === 0 ? "right" : "left");
      expect(row.character).toBeDefined();
    });
  });
});

describe("Character Animations", () => {
  it("should have float animation defined", () => {
    const floatAnimation = "@keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-20px); } }";
    expect(floatAnimation).toContain("float");
    expect(floatAnimation).toContain("translateY");
  });

  it("should have bounce animation defined", () => {
    const bounceAnimation = "@keyframes bounce-character { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-30px); } }";
    expect(bounceAnimation).toContain("bounce-character");
    expect(bounceAnimation).toContain("translateY");
  });

  it("should have slide-in animation defined", () => {
    const slideAnimation = "@keyframes slideInCharacter { from { opacity: 0; transform: translateX(-50px); } to { opacity: 1; transform: translateX(0); } }";
    expect(slideAnimation).toContain("slideInCharacter");
    expect(slideAnimation).toContain("opacity");
  });

  it("should have glow pulse animation defined", () => {
    const glowAnimation = "@keyframes glowPulse { 0%, 100% { box-shadow: 0 0 20px rgba(0, 255, 0, 0.3); } }";
    expect(glowAnimation).toContain("glowPulse");
    expect(glowAnimation).toContain("box-shadow");
  });
});

describe("Character Data Validation", () => {
  it("should have all required image URLs", () => {
    const images = [
      "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-shoe-specialist-gMbDBPCA7MhHn5RheS99Yc.webp",
      "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-cleaning-expert-ETA9KNPf4t6cmEzKTJQMco.webp",
      "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-restoration-master-WbpWqjQZbLcHTew4XaKAvR.webp",
    ];
    
    images.forEach((url) => {
      expect(url).toContain("https://");
      expect(url).toContain("cloudfront");
      expect(url).toContain("webp");
    });
  });

  it("should validate character names", () => {
    const names = ["Shoe Specialist", "Cleaning Expert", "Restoration Master"];
    
    names.forEach((name) => {
      expect(name.length).toBeGreaterThan(0);
      expect(name).toMatch(/^[A-Z]/);
    });
  });
});
