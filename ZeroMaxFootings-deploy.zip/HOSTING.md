# ZeroMaxFootings Hosting Guide

This archive contains the ZeroMaxFootings React/Vite website and its Node/Express server. The production build has already been generated in `dist/`.

## Option 1: Deploy the included production build

Use a Node.js host such as Render, Railway, Fly.io, or a VPS.

1. Upload or extract this folder.
2. Install Node.js 20 or newer and pnpm.
3. Install dependencies:

   ```bash
   pnpm install --frozen-lockfile
   ```

4. If you need to rebuild after making changes:

   ```bash
   pnpm build
   ```

5. Start the production server:

   ```bash
   pnpm start
   ```

Set the host's start command to `pnpm start`. The server listens on the `PORT` supplied by the host, or port `3000` locally.

## Option 2: Static hosting

For Netlify, Vercel static hosting, GitHub Pages, or similar services, publish the contents of `dist/public/` after running `pnpm build`. Configure SPA fallback routing so unknown paths serve `index.html`.

The included server is preferred when you want the full project runtime, database access, authentication, or future backend features.

## Environment variables

Do not commit real credentials. Add these variables in your hosting provider's secret/environment settings when needed:

```text
NODE_ENV=production
PORT=3000
DATABASE_URL=your_database_connection_string
JWT_SECRET=your_long_random_secret
VITE_APP_ID=your_app_id
VITE_OAUTH_PORTAL_URL=your_oauth_portal_url
OAUTH_SERVER_URL=your_oauth_server_url
OWNER_OPEN_ID=your_owner_open_id
BUILT_IN_FORGE_API_URL=your_forge_api_url
BUILT_IN_FORGE_API_KEY=your_forge_api_key
VITE_FRONTEND_FORGE_API_URL=your_frontend_forge_api_url
VITE_FRONTEND_FORGE_API_KEY=your_frontend_forge_api_key
VITE_ANALYTICS_ENDPOINT=optional_analytics_endpoint
VITE_ANALYTICS_WEBSITE_ID=optional_analytics_site_id
```

The public marketing pages can run without configuring the database or authentication variables, but backend-dependent features should be configured before enabling them in production.

## Database

If a database is configured, apply the existing Drizzle migrations with the project's normal database workflow. Do not run migration commands against a production database until you have verified the connection and taken a backup.

## Domain and HTTPS

Point your domain's DNS records to the hosting provider. Enable HTTPS in the provider dashboard. The currently deployed project domain is:

`https://zeromaxfoot-khbajehy.manus.space/`

## Included verification

The archive was checked with:

- `pnpm check`
- `pnpm build`

The build completed successfully. Vite reported only a CSS import-order warning and a bundle-size advisory; neither prevented the build.

## Important exclusions

This ZIP intentionally excludes `node_modules`, `.git`, local logs, and environment files. Run `pnpm install --frozen-lockfile` after extracting it.
