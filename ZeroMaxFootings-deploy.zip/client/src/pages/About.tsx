import { CheckCircle } from "lucide-react";

/* Design: Industrial Minimalism About Page
 * - Clean, organized layout with clear sections
 * - Emphasis on expertise and quality
 * - Neon green accents for key points
 */

const values = [
  {
    title: "Quality Craftsmanship",
    description: "Every restoration is treated with precision and care using professional-grade techniques.",
  },
  {
    title: "Expert Knowledge",
    description: "Years of experience working with premium footwear and sports equipment.",
  },
  {
    title: "Customer Satisfaction",
    description: "We stand behind our work with a satisfaction guarantee on all services.",
  },
  {
    title: "Premium Materials",
    description: "Only the finest materials and products used in every restoration project.",
  },
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="max-w-3xl">
            <div className="neon-line w-16 mb-8"></div>
            <h1 className="text-display-lg text-foreground mb-6">
              About ZeroMaxFootings
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              We're passionate about extending the life of your most valued footwear and accessories through expert restoration and maintenance.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div>
              <div className="neon-line w-16 mb-6"></div>
              <h2 className="text-display-md text-foreground mb-6">
                Our Story
              </h2>
              <div className="space-y-4 text-body-lg text-muted-foreground">
                <p>
                  ZeroMaxFootings was founded with a simple mission: to help people preserve and restore their most cherished footwear. We understand that your sneakers, boots, and sports gear aren't just shoes—they're investments, memories, and expressions of your personal style.
                </p>
                <p>
                  What started as a passion for sneaker culture and footwear care has evolved into a professional restoration service trusted by sneaker enthusiasts, athletes, and everyday customers alike.
                </p>
                <p>
                  We combine traditional craftsmanship with modern techniques to deliver exceptional results. Whether it's a vintage pair you want to revive or premium footwear that needs professional maintenance, we treat every project with the same level of dedication and expertise.
                </p>
              </div>
            </div>

            {/* Stats */}
            <div className="space-y-6">
              <div className="bg-secondary border border-border p-8">
                <div className="text-5xl font-bold text-accent mb-2">500+</div>
                <p className="text-body-lg text-muted-foreground">
                  Successful Restorations
                </p>
              </div>
              <div className="bg-secondary border border-border p-8">
                <div className="text-5xl font-bold text-accent mb-2">98%</div>
                <p className="text-body-lg text-muted-foreground">
                  Customer Satisfaction Rate
                </p>
              </div>
              <div className="bg-secondary border border-border p-8">
                <div className="text-5xl font-bold text-accent mb-2">10+</div>
                <p className="text-body-lg text-muted-foreground">
                  Years of Experience
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Our Core Values
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl">
              These principles guide everything we do.
            </p>
          </div>

          {/* Values Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-background border border-border p-8 hover:border-accent transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-display-sm text-foreground mb-3">
                      {value.title}
                    </h3>
                    <p className="text-body-md text-muted-foreground">
                      {value.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Diagonal divider */}
        <div className="absolute bottom-0 left-0 right-0 h-32 diagonal-cut-reverse bg-background"></div>
      </section>

      {/* Mission Statement */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="bg-secondary border border-accent/30 p-12 rounded-lg text-center">
            <div className="neon-line w-16 mx-auto mb-6"></div>
            <h2 className="text-display-md text-foreground mb-6">
              Our Mission
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              To provide exceptional footwear restoration and maintenance services that help our customers extend the life of their valued possessions while building lasting relationships based on trust, quality, and expertise.
            </p>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-secondary">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Why Choose ZeroMaxFootings?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="text-5xl mb-4">🎯</div>
              <h3 className="text-display-sm text-foreground">Precision</h3>
              <p className="text-body-md text-muted-foreground">
                Every detail matters. We use specialized techniques and tools to ensure perfect results.
              </p>
            </div>
            <div className="space-y-4">
              <div className="text-5xl mb-4">⚡</div>
              <h3 className="text-display-sm text-foreground">Speed</h3>
              <p className="text-body-md text-muted-foreground">
                Quick turnaround times without compromising on quality. Most projects completed within 5-7 days.
              </p>
            </div>
            <div className="space-y-4">
              <div className="text-5xl mb-4">💎</div>
              <h3 className="text-display-sm text-foreground">Premium Care</h3>
              <p className="text-body-md text-muted-foreground">
                Professional-grade materials and techniques used on every single restoration project.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
