import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin, Clock, MessageCircle } from "lucide-react";
import { useNotification } from "@/context/NotificationContext";
import { SEOHead } from "@/components/SEOHead";

const PHONE = "+2348100348556";
const EMAIL = "amabarajoshua019@gmail.com";
const LOCATION = "Abuja Campus UNIPORT, Choba, Rivers State";

/* Design: Industrial Minimalism Contact Page
 * - Clean contact form with neon accents
 * - Multiple contact methods
 * - Business hours and location info
 * - WhatsApp integration
 */

export default function Contact() {
  const { addNotification } = useNotification();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "shoe-repair",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate form
      if (!formData.name || !formData.email || !formData.phone || !formData.message) {
        addNotification({
          type: "warning",
          title: "Missing Information",
          message: "Please fill in all required fields.",
          duration: 5000,
        });
        setIsSubmitting(false);
        return;
      }

      // Simulate form submission
      await new Promise((resolve) => setTimeout(resolve, 1000));
      addNotification({
        type: "success",
        title: "Message Sent!",
        message: "Thank you! We'll contact you soon to confirm your booking.",
        duration: 5000,
      });
      setFormData({
        name: "",
        email: "",
        phone: "",
        service: "shoe-repair",
        message: "",
      });
    } catch (error) {
      addNotification({
        type: "error",
        title: "Error",
        message: "Something went wrong. Please try again.",
        duration: 5000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const businessHours = [
    { day: "Monday - Friday", hours: "9:00 AM - 6:00 PM" },
    { day: "Saturday", hours: "10:00 AM - 4:00 PM" },
    { day: "Sunday", hours: "Closed" },
  ];

  return (
    <>
      <SEOHead
        title="Contact Us"
        description="Get in touch with ZeroMaxFootings for professional footwear repair and restoration services. Book a service, request a quote, or contact us via WhatsApp, phone, or email."
        keywords="contact footwear repair, book shoe repair service, footwear restoration inquiry, professional shoe care contact"
        ogUrl="https://zeromaxfoot-khbajehy.manus.space/contact"
      />
      <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="max-w-3xl">
            <div className="neon-line w-16 mb-8"></div>
            <h1 className="text-display-lg text-foreground mb-6">
              Get in Touch
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Ready to restore your footwear? Contact us today to book a service or get a free consultation.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Information */}
            <div className="lg:col-span-1">
              <div className="mb-12">
                <div className="neon-line w-16 mb-6"></div>
                <h2 className="text-display-md text-foreground mb-8">
                  Contact Info
                </h2>

                {/* Phone */}
                <div className="mb-8">
                  <div className="flex items-start gap-4">
                    <Phone className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-foreground mb-2">Phone</h3>
                    <a
                      href={`tel:${PHONE}`}
                      className="text-muted-foreground hover:text-accent transition-colors"
                    >
                      {PHONE}
                    </a>
                  </div>
                  </div>
                </div>

                {/* Email */}
                <div className="mb-8">
                  <div className="flex items-start gap-4">
                    <Mail className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-foreground mb-2">Email</h3>
                    <a
                      href={`mailto:${EMAIL}`}
                      className="text-muted-foreground hover:text-accent transition-colors"
                    >
                      {EMAIL}
                    </a>
                  </div>
                  </div>
                </div>

                {/* Location */}
                <div className="mb-8">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-foreground mb-2">Location</h3>
                    <p className="text-muted-foreground">
                      {LOCATION}
                    </p>
                  </div>
                  </div>
                </div>

                {/* Business Hours */}
                <div className="bg-secondary border border-border p-6 rounded">
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="w-5 h-5 text-accent" />
                    <h3 className="font-bold text-foreground">Business Hours</h3>
                  </div>
                  <ul className="space-y-2">
                    {businessHours.map((item, idx) => (
                      <li key={idx} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">
                          {item.day}
                        </span>
                        <span className="text-foreground font-medium">
                          {item.hours}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* WhatsApp Button */}
              <a
                href={`https://wa.me/${PHONE.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Button className="w-full bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300 group">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Chat on WhatsApp
                </Button>
              </a>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-secondary border border-border p-8 rounded-lg">
                <h2 className="text-display-md text-foreground mb-8">
                  Send us a Message
                </h2>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Name */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full bg-background border border-border text-foreground px-4 py-3 rounded focus:outline-none focus:border-accent transition-colors"
                      placeholder="Your name"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full bg-background border border-border text-foreground px-4 py-3 rounded focus:outline-none focus:border-accent transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full bg-background border border-border text-foreground px-4 py-3 rounded focus:outline-none focus:border-accent transition-colors"
                      placeholder="+1 (234) 567-890"
                    />
                  </div>

                  {/* Service */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Service Interested In
                    </label>
                    <select
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      className="w-full bg-background border border-border text-foreground px-4 py-3 rounded focus:outline-none focus:border-accent transition-colors"
                    >
                      <option value="shoe-repair">Shoe Repair</option>
                      <option value="football-boot-repair">Football Boot Repair</option>
                      <option value="bag-repair">Bag Repair</option>
                      <option value="footwear-laundry">Footwear Laundry</option>
                      <option value="shoe-polishing">Shoe Polishing</option>
                      <option value="shoe-revamping">Shoe Revamping</option>
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Message
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={5}
                      className="w-full bg-background border border-border text-foreground px-4 py-3 rounded focus:outline-none focus:border-accent transition-colors resize-none"
                      placeholder="Tell us about your footwear and what you need..."
                    />
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300"
                  >
                    {isSubmitting ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pickup & Delivery */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Pickup & Delivery Service
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl">
              Can't make it to our location? We offer convenient pickup and delivery services for your area.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-background border border-border p-8 text-center">
              <div className="text-5xl mb-4">🚚</div>
              <h3 className="text-display-sm text-foreground mb-3">
                Free Pickup
              </h3>
              <p className="text-body-md text-muted-foreground">
                We'll pick up your items from your location at no extra charge.
              </p>
            </div>
            <div className="bg-background border border-border p-8 text-center">
              <div className="text-5xl mb-4">⚡</div>
              <h3 className="text-display-sm text-foreground mb-3">
                Fast Service
              </h3>
              <p className="text-body-md text-muted-foreground">
                Quick turnaround times with most projects completed in 5-7 days.
              </p>
            </div>
            <div className="bg-background border border-border p-8 text-center">
              <div className="text-5xl mb-4">📦</div>
              <h3 className="text-display-sm text-foreground mb-3">
                Safe Delivery
              </h3>
              <p className="text-body-md text-muted-foreground">
                Your restored items are carefully packaged and delivered back to you.
              </p>
            </div>
          </div>
        </div>

        {/* Diagonal divider */}
        <div className="absolute bottom-0 left-0 right-0 h-32 diagonal-cut-reverse bg-background"></div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                q: "How long does restoration take?",
                a: "Most projects are completed within 5-7 business days. Express service available for urgent requests.",
              },
              {
                q: "What's your pricing?",
                a: "Pricing varies by service and damage level. We offer free consultations to assess your items.",
              },
              {
                q: "Do you offer warranties?",
                a: "Yes, we provide a satisfaction guarantee on all our restoration work.",
              },
              {
                q: "Can you handle premium brands?",
                a: "Absolutely! We specialize in premium footwear and use only the finest materials.",
              },
            ].map((faq, idx) => (
              <div key={idx} className="bg-secondary border border-border p-6">
                <h3 className="font-bold text-foreground mb-3">{faq.q}</h3>
                <p className="text-body-md text-muted-foreground">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      </div>
    </>
  );
}
