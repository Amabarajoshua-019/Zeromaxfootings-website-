import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

/* Design: Industrial Minimalism 404 Page
 * - Bold neon accent color
 * - Clear navigation back to home
 */

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="container text-center py-24">
        <div className="mb-8">
          <div className="text-9xl font-bold text-accent mb-4">404</div>
          <h1 className="text-display-lg text-foreground mb-4">
            Page Not Found
          </h1>
          <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Sorry, the page you're looking for doesn't exist. Let's get you back on track.
          </p>
        </div>

        <Link href="/">
          <a>
            <Button className="bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </a>
        </Link>
      </div>
    </div>
  );
}
