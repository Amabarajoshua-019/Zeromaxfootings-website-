import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Clock, Zap } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";
import { ServiceGuideCharacterRow } from "@/components/ServiceGuideCharacter";

/* Design: Industrial Minimalism Services Page
 * - Detailed service cards with pricing and features
 * - Clear descriptions and turnaround times
 * - CTA for each service
 */

const SERVICES_ICONS = "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/service-icons-composite-mUPrEGUZ52rpqRfGR6aaVB.webp";

const services = [
  {
    id: 1,
    title: "Shoe Repair",
    icon: "🔧",
    price: "₦1,000 - ₦10,000",
    turnaround: "3-5 days",
    description: "Professional repair for all types of footwear including sole replacement, heel repair, stitching, and structural fixes.",
    features: [
      "Sole replacement and repair",
      "Heel restoration",
      "Stitching and seam repair",
      "Structural damage fixes",
      "Leather and material repairs",
    ],
  },
  {
    id: 2,
    title: "Football Boot Repair",
    icon: "⚽",
    price: "₦8,000",
    turnaround: "5-7 days",
    description: "Specialized restoration for sports footwear. We handle studs, soles, and performance-critical repairs.",
    features: [
      "Stud replacement",
      "Sole and heel repair",
      "Performance restoration",
      "Leather conditioning",
      "Structural reinforcement",
    ],
  },
  {
    id: 3,
    title: "Bag Repair",
    icon: "👜",
    price: "₦1,000 - ₦6,000",
    turnaround: "3-5 days",
    description: "Expert repair for leather bags, backpacks, and accessories. We fix zippers, handles, seams, and more.",
    features: [
      "Zipper replacement",
      "Handle and strap repair",
      "Seam and stitching fixes",
      "Leather patching",
      "Buckle and hardware repair",
    ],
  },
  {
    id: 4,
    title: "Footwear Laundry",
    icon: "💧",
    price: "₦1,500",
    turnaround: "2-3 days",
    description: "Deep cleaning and sanitization for your footwear. We remove dirt, stains, and odors while preserving materials.",
    features: [
      "Deep cleaning",
      "Stain removal",
      "Sanitization",
      "Odor elimination",
      "Material-specific care",
    ],
  },
  {
    id: 5,
    title: "Shoe Polishing",
    icon: "✨",
    price: "₦200 - ₦1,000",
    turnaround: "1-2 days",
    description: "Professional polishing and finishing to restore shine and protect your footwear from damage.",
    features: [
      "Premium polishing",
      "Protective coating",
      "Color restoration",
      "Shine enhancement",
      "Material conditioning",
    ],
  },
  {
    id: 6,
    title: "Shoe Revamping",
    icon: "🔄",
    price: "₦5,000 - ₦10,000",
    turnaround: "7-10 days",
    description: "Complete restoration to make old shoes look brand new. Includes cleaning, repair, and finishing.",
    features: [
      "Complete restoration",
      "Color restoration",
      "Full cleaning and repair",
      "Premium finishing",
      "Like-new appearance",
    ],
  },
];

export default function Services() {
  return (
    <>
      <SEOHead
        title="Services"
        description="Professional footwear services including shoe repair, football boot restoration, bag repair, footwear laundry, polishing, and revamping. Affordable pricing in Abuja, Nigeria."
        keywords="shoe repair services, football boot repair, bag repair, footwear laundry, shoe polishing, shoe revamping, professional shoe care"
        ogUrl="https://zeromaxfoot-khbajehy.manus.space/services"
      />
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="max-w-3xl">
            <div className="neon-line w-16 mb-8"></div>
            <h1 className="text-display-lg text-foreground mb-6">
              Our Services
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Professional footwear maintenance and restoration services tailored to your needs. From simple cleaning to complete revamping, we've got you covered.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <div
                key={service.id}
                className="bg-secondary border border-border hover:border-accent transition-all duration-300 group overflow-hidden"
              >
                {/* Header */}
                <div className="p-8 border-b border-border bg-gradient-to-br from-secondary to-background">
                  <div className="text-6xl mb-4">{service.icon}</div>
                  <h3 className="text-display-sm text-foreground mb-2">
                    {service.title}
                  </h3>
                  <p className="text-body-md text-muted-foreground">
                    {service.description}
                  </p>
                </div>

                {/* Pricing & Turnaround */}
                <div className="p-8 space-y-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Price Range</span>
                    <span className="text-lg font-bold text-accent">
                      {service.price}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-4 h-4 text-accent" />
                    <span className="text-sm">
                      Turnaround: {service.turnaround}
                    </span>
                  </div>
                </div>

                {/* Features */}
                <div className="p-8 space-y-3 mb-8">
                  {service.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <Zap className="w-4 h-4 text-accent flex-shrink-0 mt-1" />
                      <span className="text-sm text-muted-foreground">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <div className="p-8 pt-0">
                  <Link href="/contact">
                    <a className="block">
                      <Button className="w-full bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300 group">
                        Book This Service
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </a>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Packages */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Special Packages
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl">
              Save more with our bundled service packages.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Starter Package */}
            <div className="bg-background border border-border p-8 hover:border-accent transition-all duration-300">
              <h3 className="text-display-sm text-foreground mb-4">
                Starter Package
              </h3>
              <div className="text-4xl font-bold text-accent mb-6">$49</div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Cleaning & polishing</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Minor repairs</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Protective coating</span>
                </li>
              </ul>
              <Link href="/contact">
                <a>
                  <Button className="w-full bg-accent text-background">
                    Choose Package
                  </Button>
                </a>
              </Link>
            </div>

            {/* Premium Package */}
            <div className="bg-background border-2 border-accent p-8 relative">
              <div className="absolute top-0 right-0 bg-accent text-background px-4 py-1 text-sm font-bold">
                POPULAR
              </div>
              <h3 className="text-display-sm text-foreground mb-4">
                Premium Package
              </h3>
              <div className="text-4xl font-bold text-accent mb-6">$129</div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Complete restoration</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>All repairs included</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Premium finishing</span>
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <Zap className="w-4 h-4 text-accent" />
                  <span>Satisfaction guarantee</span>
                </li>
              </ul>
              <Link href="/contact">
                <a>
                  <Button className="w-full bg-accent text-background hover:shadow-lg hover:shadow-accent/50">
                    Choose Package
                  </Button>
                </a>
              </Link>
            </div>
          </div>
        </div>

        {/* Diagonal divider */}
        <div className="absolute bottom-0 left-0 right-0 h-32 diagonal-cut-reverse bg-background"></div>
      </section>

      {/* Process Section */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              How It Works
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { step: "1", title: "Book", desc: "Schedule your service online or via WhatsApp" },
              { step: "2", title: "Drop Off", desc: "Bring your items to our location" },
              { step: "3", title: "Restoration", desc: "We work our magic with expert care" },
              { step: "4", title: "Pickup", desc: "Collect your restored items" },
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="w-16 h-16 bg-accent text-background rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="text-display-sm text-foreground mb-2">
                  {item.title}
                </h3>
                <p className="text-body-md text-muted-foreground">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-secondary">
        <div className="container">
          <div className="bg-background border border-accent/30 p-12 rounded-lg text-center">
            <div className="neon-line w-16 mx-auto mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Book your service today and experience professional footwear restoration.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <a>
                  <Button className="bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300">
                    Book a Service
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </a>
              </Link>
              <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                <Button
                  variant="outline"
                  className="border-accent text-accent hover:bg-accent hover:text-background transition-all duration-300"
                >
                  Chat on WhatsApp
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Service Guide Character Section */}
      <ServiceGuideCharacterRow
        title="Expert Shoe Repair"
        description="Our shoe repair specialist brings years of experience to restore your footwear to pristine condition. From sole replacement to structural repairs, we handle every detail with precision."
        character="specialist"
        position="right"
        content={
          <div className="space-y-4">
            <ul className="space-y-2">
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Professional sole replacement</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Heel restoration and repair</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Precision stitching and seam work</span>
              </li>
            </ul>
            <Link href="/contact">
              <Button className="bg-accent text-background hover:bg-accent/90 w-full">
                Book Repair Service
              </Button>
            </Link>
          </div>
        }
      />

      {/* Cleaning Expert Section */}
      <ServiceGuideCharacterRow
        title="Professional Footwear Cleaning"
        description="Our cleaning expert uses advanced techniques and premium products to restore your footwear to like-new condition. Deep cleaning, sanitization, and protective treatment included."
        character="cleaning"
        position="left"
        content={
          <div className="space-y-4">
            <ul className="space-y-2">
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Deep cleaning and sanitization</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Stain removal and restoration</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Protective coating application</span>
              </li>
            </ul>
            <Link href="/contact">
              <Button className="bg-accent text-background hover:bg-accent/90 w-full">
                Book Cleaning Service
              </Button>
            </Link>
          </div>
        }
      />

      {/* Restoration Master Section */}
      <ServiceGuideCharacterRow
        title="Master Restoration & Revamping"
        description="Our restoration master specializes in bringing old, worn footwear back to life. Complete revamping, color restoration, and structural reinforcement for maximum longevity."
        character="restoration"
        position="right"
        content={
          <div className="space-y-4">
            <ul className="space-y-2">
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Complete shoe revamping</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Color restoration and dyeing</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent font-bold">✓</span>
                <span className="text-foreground">Structural reinforcement</span>
              </li>
            </ul>
            <Link href="/contact">
              <Button className="bg-accent text-background hover:bg-accent/90 w-full">
                Book Revamping Service
              </Button>
            </Link>
          </div>
        }
      />
      </div>
    </>
  );
}
