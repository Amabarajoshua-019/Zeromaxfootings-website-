import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

/* Design: Industrial Minimalism Gallery Page
 * - Interactive before/after image slider
 * - Grid gallery with hover effects
 * - Transformation showcase
 */

const galleryItems = [
  {
    id: 1,
    title: "Premium Sneaker Restoration",
    category: "Shoe Repair",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/before-after-sneaker-1-KvK7JiKZAs6F7kdb7ZXahL.webp",
  },
  {
    id: 2,
    title: "Football Boot Professional Restoration",
    category: "Sports Repair",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/before-after-football-boot-1-3waUoq3YqRr3ukNT7TmkxX.webp",
  },
  {
    id: 3,
    title: "Luxury Leather Bag Restoration",
    category: "Bag Repair",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/before-after-leather-bag-jwRmKzxajbXMg5AbkRtimo.webp",
  },
  {
    id: 4,
    title: "Premium Football Boot Revival",
    category: "Sports Repair",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/before-after-football-boot-2-MyyQM4VQPM6h5NPTR4JoQL.webp",
  },
  {
    id: 5,
    title: "Casual Shoe Revamping",
    category: "Revamping",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/before-after-casual-shoe-5ChpSp7ssvw9WLQ4vWGNZM.webp",
  },
];

const testimonials = [
  {
    name: "Alex Johnson",
    role: "Sneaker Collector",
    text: "Absolutely incredible work! My vintage Jordans look brand new. The attention to detail is unmatched.",
    rating: 5,
  },
  {
    name: "Sarah Chen",
    role: "Athlete",
    text: "My football boots were damaged beyond what I thought was possible to fix. ZeroMaxFootings brought them back to life!",
    rating: 5,
  },
  {
    name: "Marcus Williams",
    role: "Casual Customer",
    text: "Fast, professional, and affordable. Highly recommend for anyone looking to restore their footwear.",
    rating: 5,
  },
];

export default function Gallery() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeFilter, setActiveFilter] = useState("All");

  const filters = ["All", "Shoe Repair", "Sports Repair", "Bag Repair", "Revamping"];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % galleryItems.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) =>
      prev === 0 ? galleryItems.length - 1 : prev - 1
    );
  };

  return (
    <>
      <SEOHead
        title="Gallery"
        description="Before and after gallery showcasing professional footwear restoration transformations. See stunning results of our shoe repair, football boot restoration, and bag repair services."
        keywords="before after shoe repair, footwear restoration gallery, shoe transformation, professional shoe care results"
        ogUrl="https://zeromaxfoot-khbajehy.manus.space/gallery"
      />
      <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="max-w-3xl">
            <div className="neon-line w-16 mb-8"></div>
            <h1 className="text-display-lg text-foreground mb-6">
              Transformation Gallery
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              See the remarkable transformations we've achieved. From damaged to pristine, these are real results from our expert restoration work.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Slider */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Featured Transformations
            </h2>
          </div>

          {/* Slider */}
          <div className="relative bg-secondary border border-border rounded-lg overflow-hidden group">
            {/* Image */}
            <div className="relative h-96 md:h-[500px] overflow-hidden">
              <img
                src={galleryItems[currentSlide].image}
                alt={galleryItems[currentSlide].title}
                className="w-full h-full object-cover transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/20"></div>
            </div>

            {/* Content Overlay */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-8">
              <h3 className="text-display-sm text-white mb-2">
                {galleryItems[currentSlide].title}
              </h3>
              <p className="text-body-md text-gray-300">
                {galleryItems[currentSlide].category}
              </p>
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-accent/80 hover:bg-accent text-background p-3 rounded transition-all duration-300 opacity-0 group-hover:opacity-100"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-accent/80 hover:bg-accent text-background p-3 rounded transition-all duration-300 opacity-0 group-hover:opacity-100"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Slide Indicators */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              {galleryItems.map((_, idx) => (
                   <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    idx === currentSlide ? "bg-accent w-8" : "bg-white/50 hover:bg-white"
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Slide Counter */}
          <div className="mt-6 text-center text-muted-foreground">
            {currentSlide + 1} / {galleryItems.length}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          <div className="mb-12">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-8">
              All Projects
            </h2>

            {/* Filter Buttons */}
            <div className="flex flex-wrap gap-3">
              {filters.map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-6 py-2 rounded transition-all duration-300 font-medium ${activeFilter === filter ? "bg-accent text-background" : "bg-background text-foreground border border-border hover:border-accent"}`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryItems.map((item) => {
              const isActive = activeFilter === "All" || item.category === activeFilter;
              return isActive ? (
                <div
                  key={item.id}
                  className="group relative overflow-hidden rounded-lg border border-border hover:border-accent transition-all duration-300 cursor-pointer h-64"
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-all duration-300 flex items-end p-6">
                    <div className="translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                      <h3 className="text-display-sm text-white mb-1">
                        {item.title}
                      </h3>
                      <p className="text-body-md text-gray-300">
                        {item.category}
                      </p>
                    </div>
                  </div>
                </div>
              ) : null;
            })}
          </div>
        </div>

        {/* Diagonal divider */}
        <div className="absolute bottom-0 left-0 right-0 h-32 diagonal-cut-reverse bg-background"></div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="mb-16">
            <div className="neon-line w-16 mb-6"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Customer Testimonials
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl">
              See what our satisfied customers have to say about our restoration services.
            </p>
          </div>

          {/* Testimonials Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <div
                key={idx}
                className="bg-secondary border border-border p-8 hover:border-accent transition-all duration-300"
              >
                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <span key={i} className="text-2xl text-accent">
                      ★
                    </span>
                  ))}
                </div>

                {/* Quote */}
                <p className="text-body-lg text-muted-foreground mb-6 italic">
                  "{testimonial.text}"
                </p>

                {/* Author */}
                <div>
                  <h4 className="font-bold text-foreground">
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-secondary">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold text-accent mb-2">500+</div>
              <p className="text-body-lg text-muted-foreground">
                Projects Completed
              </p>
            </div>
            <div>
              <div className="text-5xl font-bold text-accent mb-2">98%</div>
              <p className="text-body-lg text-muted-foreground">
                Satisfaction Rate
              </p>
            </div>
            <div>
              <div className="text-5xl font-bold text-accent mb-2">5-7</div>
              <p className="text-body-lg text-muted-foreground">
                Day Turnaround
              </p>
            </div>
            <div>
              <div className="text-5xl font-bold text-accent mb-2">10+</div>
              <p className="text-body-lg text-muted-foreground">
                Years Experience
              </p>
            </div>
          </div>
        </div>
      </section>
      </div>
    </>
  );
}
