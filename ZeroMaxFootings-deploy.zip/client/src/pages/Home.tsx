import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Zap } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

/* Design: Industrial Minimalism Home Page
 * - Bold hero section with neon green accents
 * - Before/after image showcase with dramatic transformation
 * - Featured services with geometric cards
 * - Asymmetric layout with diagonal dividers
 */

const HERO_BANNER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/hero-banner-dark-aZxq5kgLFhM3eheN58YPzQ.webp";
const BEFORE_AFTER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/hero-before-after-W6E5HZaMeXZP79Aw9PxYqi.webp";
const RESTORATION_PROCESS = "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/restoration-process-jMKfEHw5bJW8A3.webp";

const services = [
  {
    title: "Shoe Repair",
    description: "Professional repair for all types of footwear",
    icon: "🔧",
  },
  {
    title: "Football Boot Repair",
    description: "Specialized care for sports equipment",
    icon: "⚽",
  },
  {
    title: "Footwear Laundry",
    description: "Deep cleaning and sanitization",
    icon: "💧",
  },
];

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  return (
    <>
      <SEOHead
        title="Home"
        description="Professional footwear restoration and repair services in Abuja, Nigeria. Expert sneaker repair, football boot restoration, bag repair, and more."
        keywords="footwear repair Abuja, shoe restoration, sneaker cleaning, football boot repair, professional shoe care"
        ogUrl="https://zeromaxfoot-khbajehy.manus.space/"
      />
      <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img
            src={HERO_BANNER}
            alt="Footwear restoration"
            className="w-full h-full object-cover"
          />
          {/* Dark Overlay */}
          <div className="absolute inset-0 bg-black/40"></div>
        </div>

        {/* Content */}
        <div className="container relative z-10 py-20">
          <div className="max-w-2xl">
            {/* Neon accent line */}
            <div className="neon-line w-16 mb-8"></div>

            {/* Headline */}
            <h1 className="text-display-lg text-white mb-4 leading-tight">
              Bring Your Footwear Back to Life
            </h1>

            {/* Subheadline */}
            <p className="text-xl text-gray-200 mb-8 font-light">
              Repairs • Cleaning • Revamping • Protection
            </p>

            {/* Description */}
            <p className="text-body-lg text-gray-300 mb-12 max-w-lg">
              Professional footwear maintenance and restoration for sneakers, football boots, bags, and accessories. We help you restore, clean, protect, and extend the life of your most valued possessions.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact">
                <a>
                  <Button className="bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300 group">
                    Book a Service
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </a>
              </Link>
              <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                <Button
                  variant="outline"
                  className="border-accent text-accent hover:bg-accent hover:text-background transition-all duration-300"
                >
                  Contact Us
                </Button>
              </a>
            </div>
          </div>
        </div>

        {/* Neon accent element */}
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl -z-10"></div>
      </section>

      {/* Before/After Showcase */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          {/* Section Header */}
          <div className="mb-16">
            <div className="neon-line w-16 mb-4"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Transformation Results
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl">
              See the dramatic difference our expert restoration services can make. From damaged to pristine in just a few days.
            </p>
          </div>

          {/* Before/After Image */}
          <div className="rounded-lg overflow-hidden border border-border shadow-2xl">
            <img
              src={BEFORE_AFTER}
              alt="Before and after restoration"
              className="w-full h-auto"
            />
          </div>
        </div>

        {/* Diagonal divider */}
        <div className="absolute bottom-0 left-0 right-0 h-32 diagonal-cut-reverse bg-background"></div>
      </section>

      {/* Featured Services */}
      <section className="py-24 bg-background">
        <div className="container">
          {/* Section Header */}
          <div className="mb-16">
            <div className="neon-line w-16 mb-4"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Our Services
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl">
              Professional expertise across all footwear maintenance and repair services.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-secondary border border-border p-8 hover:border-accent transition-all duration-300 group cursor-pointer"
              >
                {/* Icon */}
                <div className="text-5xl mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>

                {/* Title */}
                <h3 className="text-display-sm text-foreground mb-3">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-body-md text-muted-foreground mb-6">
                  {service.description}
                </p>

                {/* Arrow indicator */}
                <div className="flex items-center gap-2 text-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="text-sm font-bold">Learn More</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>

          {/* View All Services Button */}
          <div className="flex justify-center">
            <Link href="/services">
              <a>
                <Button className="bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300">
                  View All Services
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Restoration Process */}
      <section className="py-24 bg-secondary relative overflow-hidden">
        <div className="container">
          {/* Section Header */}
          <div className="mb-16">
            <div className="neon-line w-16 mb-4"></div>
            <h2 className="text-display-md text-foreground mb-4">
              Our Process
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl">
              A systematic approach to restore your footwear to its original condition.
            </p>
          </div>

          {/* Process Image */}
          <div className="rounded-lg overflow-hidden border border-border shadow-2xl">
            <img
              src={RESTORATION_PROCESS}
              alt="Restoration process steps"
              className="w-full h-auto"
            />
          </div>
        </div>

        {/* Diagonal divider */}
        <div className="absolute bottom-0 left-0 right-0 h-32 diagonal-cut bg-background"></div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="bg-secondary border border-accent/30 p-12 rounded-lg text-center relative overflow-hidden group">
            {/* Background accent */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl -z-10 group-hover:bg-accent/10 transition-all duration-300"></div>

            {/* Icon */}
            <Zap className="w-16 h-16 text-accent mx-auto mb-6" />

            {/* Heading */}
            <h2 className="text-display-md text-foreground mb-4">
              Ready to Restore?
            </h2>

            {/* Description */}
            <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Get your footwear looking brand new. Contact us today for a free consultation or book your service online.
            </p>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <a>
                  <Button className="bg-accent text-background hover:shadow-lg hover:shadow-accent/50 transition-all duration-300">
                    Book Now
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </a>
              </Link>
              <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                <Button
                  variant="outline"
                  className="border-accent text-accent hover:bg-accent hover:text-background transition-all duration-300"
                >
                  Chat on WhatsApp
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>
      </div>
    </>
  );
}
