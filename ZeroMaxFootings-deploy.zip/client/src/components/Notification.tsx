import { useEffect, useState } from "react";
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from "lucide-react";
import { Notification as NotificationType } from "@/context/NotificationContext";

interface NotificationProps {
  notification: NotificationType;
  onRemove: (id: string) => void;
}

export function Notification({ notification, onRemove }: NotificationProps) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    // Add enter animation
    const timer = setTimeout(() => {
      // Component will be visible
    }, 10);

    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setIsExiting(true);
    setTimeout(() => {
      onRemove(notification.id);
    }, 300); // Match animation duration
  };

  const getIcon = () => {
    switch (notification.type) {
      case "success":
        return <CheckCircle className="w-5 h-5" />;
      case "error":
        return <AlertCircle className="w-5 h-5" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5" />;
      case "info":
      default:
        return <Info className="w-5 h-5" />;
    }
  };

  const getColors = () => {
    switch (notification.type) {
      case "success":
        return {
          bg: "bg-green-50 border-green-200",
          icon: "text-green-600",
          text: "text-green-800",
          title: "text-green-900",
        };
      case "error":
        return {
          bg: "bg-red-50 border-red-200",
          icon: "text-red-600",
          text: "text-red-800",
          title: "text-red-900",
        };
      case "warning":
        return {
          bg: "bg-yellow-50 border-yellow-200",
          icon: "text-yellow-600",
          text: "text-yellow-800",
          title: "text-yellow-900",
        };
      case "info":
      default:
        return {
          bg: "bg-blue-50 border-blue-200",
          icon: "text-blue-600",
          text: "text-blue-800",
          title: "text-blue-900",
        };
    }
  };

  const colors = getColors();

  return (
    <div
      className={`transform transition-all duration-300 ${
        isExiting
          ? "translate-x-full opacity-0"
          : "translate-x-0 opacity-100"
      }`}
    >
      <div
        className={`flex items-start gap-3 p-4 rounded-lg border ${colors.bg} shadow-lg`}
      >
        <div className={colors.icon}>{getIcon()}</div>
        <div className="flex-1 min-w-0">
          <h3 className={`font-semibold ${colors.title} text-sm`}>
            {notification.title}
          </h3>
          <p className={`text-sm ${colors.text} mt-1`}>
            {notification.message}
          </p>
        </div>
        <button
          onClick={handleClose}
          className={`flex-shrink-0 ${colors.icon} hover:opacity-70 transition-opacity`}
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
