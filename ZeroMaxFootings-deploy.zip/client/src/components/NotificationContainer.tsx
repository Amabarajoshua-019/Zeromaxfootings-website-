import { useNotification } from "@/context/NotificationContext";
import { Notification } from "./Notification";

/* NotificationContainer
 * - Displays all active notifications
 * - Fixed position in top-right corner
 * - Stacked vertically with animations
 */

export function NotificationContainer() {
  const { notifications, removeNotification } = useNotification();

  return (
    <div className="fixed top-6 right-6 z-50 flex flex-col gap-3 pointer-events-none max-w-md">
      {notifications.map((notification) => (
        <div key={notification.id} className="pointer-events-auto">
          <Notification
            notification={notification}
            onRemove={removeNotification}
          />
        </div>
      ))}
    </div>
  );
}
