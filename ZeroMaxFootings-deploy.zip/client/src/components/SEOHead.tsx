import { useEffect } from "react";

interface SEOHeadProps {
  title: string;
  description: string;
  keywords?: string;
  ogImage?: string;
  ogUrl?: string;
  schema?: Record<string, unknown>;
}

/**
 * SEOHead Component
 * Updates document head with SEO meta tags and structured data for each page
 * Improves search engine visibility and social media sharing
 */
export function SEOHead({
  title,
  description,
  keywords,
  ogImage,
  ogUrl,
  schema,
}: SEOHeadProps) {
  useEffect(() => {
    // Update page title
    document.title = `${title} | ZeroMaxFootings`;

    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", description);
    }

    // Update meta keywords
    if (keywords) {
      let metaKeywords = document.querySelector('meta[name="keywords"]');
      if (!metaKeywords) {
        metaKeywords = document.createElement("meta");
        metaKeywords.setAttribute("name", "keywords");
        document.head.appendChild(metaKeywords);
      }
      metaKeywords.setAttribute("content", keywords);
    }

    // Update Open Graph tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute("content", title);
    }

    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) {
      ogDesc.setAttribute("content", description);
    }

    if (ogImage) {
      let ogImageTag = document.querySelector('meta[property="og:image"]');
      if (!ogImageTag) {
        ogImageTag = document.createElement("meta");
        ogImageTag.setAttribute("property", "og:image");
        document.head.appendChild(ogImageTag);
      }
      ogImageTag.setAttribute("content", ogImage);
    }

    if (ogUrl) {
      let ogUrlTag = document.querySelector('meta[property="og:url"]');
      if (!ogUrlTag) {
        ogUrlTag = document.createElement("meta");
        ogUrlTag.setAttribute("property", "og:url");
        document.head.appendChild(ogUrlTag);
      }
      ogUrlTag.setAttribute("content", ogUrl);
    }

    // Update JSON-LD schema if provided
    if (schema) {
      let schemaScript = document.querySelector('script[type="application/ld+json"][data-page-schema]');
      if (!schemaScript) {
        schemaScript = document.createElement("script");
        schemaScript.setAttribute("type", "application/ld+json");
        schemaScript.setAttribute("data-page-schema", "true");
        document.head.appendChild(schemaScript);
      }
      schemaScript.textContent = JSON.stringify(schema);
    }

    // Update canonical URL
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      document.head.appendChild(canonical);
    }
    canonical.setAttribute("href", ogUrl || window.location.href);
  }, [title, description, keywords, ogImage, ogUrl, schema]);

  return null; // This component only updates the head, doesn't render anything
}
