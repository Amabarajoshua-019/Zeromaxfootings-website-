import { useEffect, useState } from "react";

interface ServiceGuideCharacterProps {
  character: "specialist" | "cleaning" | "restoration";
  position?: "left" | "right";
  animationType?: "float" | "bounce" | "slide";
}

/**
 * ServiceGuideCharacter Component
 * Displays realistic animated service guide characters on specific pages
 * Characters provide visual engagement and guide users through services
 */
export function ServiceGuideCharacter({
  character,
  position = "right",
  animationType = "float",
}: ServiceGuideCharacterProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger animation after component mounts
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const characterData = {
    specialist: {
      name: "Shoe Specialist",
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-shoe-specialist-gMbDBPCA7MhHn5RheS99Yc.webp",
      alt: "Professional shoe repair specialist",
    },
    cleaning: {
      name: "Cleaning Expert",
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-cleaning-expert-ETA9KNPf4t6cmEzKTJQMco.webp",
      alt: "Professional footwear cleaning expert",
    },
    restoration: {
      name: "Restoration Master",
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663497963858/KhBAjEhYQmvUwaDHZqJGoL/character-restoration-master-WbpWqjQZbLcHTew4XaKAvR.webp",
      alt: "Expert restoration specialist",
    },
  };

  const data = characterData[character];

  const animationClass = {
    float: "animate-float",
    bounce: "animate-bounce",
    slide: "animate-slide-in",
  }[animationType];

  return (
    <div
      className={`flex flex-col items-center gap-4 ${
        position === "left" ? "md:order-first" : "md:order-last"
      }`}
    >
      <div
        className={`relative w-48 h-64 md:w-56 md:h-72 transition-all duration-1000 ${
          isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
        } ${animationClass}`}
      >
        {/* Character Image */}
        <img
          src={data.image}
          alt={data.alt}
          className="w-full h-full object-cover rounded-lg shadow-2xl"
        />

        {/* Neon Glow Effect */}
        <div className="absolute inset-0 rounded-lg bg-gradient-to-t from-accent/20 to-transparent pointer-events-none" />

        {/* Animated Border */}
        <div className="absolute inset-0 rounded-lg border-2 border-accent/50 animate-pulse" />
      </div>

      {/* Character Name */}
      <div className="text-center">
        <h3 className="text-lg font-bold text-foreground">{data.name}</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Expert Guide
        </p>
      </div>
    </div>
  );
}

/**
 * ServiceGuideCharacterRow Component
 * Displays multiple characters in a row with alternating positions
 */
interface ServiceGuideCharacterRowProps {
  title: string;
  description: string;
  character: "specialist" | "cleaning" | "restoration";
  content: React.ReactNode;
  position?: "left" | "right";
}

export function ServiceGuideCharacterRow({
  title,
  description,
  character,
  content,
  position = "right",
}: ServiceGuideCharacterRowProps) {
  return (
    <section className="py-16 bg-secondary/50">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Content Side */}
          <div className={position === "right" ? "md:order-first" : ""}>
            <div className="neon-line w-12 mb-6"></div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              {title}
            </h2>
            <p className="text-lg text-muted-foreground mb-8">{description}</p>
            {content}
          </div>

          {/* Character Side */}
          <div className={position === "right" ? "md:order-last" : ""}>
            <ServiceGuideCharacter
              character={character}
              position={position}
              animationType="float"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
